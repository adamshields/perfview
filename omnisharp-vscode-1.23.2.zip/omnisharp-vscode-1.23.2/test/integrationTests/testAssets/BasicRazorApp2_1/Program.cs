﻿using System;

namespace BasicRazorApp2_1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("This application is not intended to be run. It exists only for VS Code Razor Extension functional testing.");
        }
    }
}
