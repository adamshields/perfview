using System.IO;

namespace Foo
{
    public class SecondaryDiagnostics
    {
        public void FooBarBar()
        {
            var notUsed = 3;
        }
    }
}