using System;

namespace minimal
{
    public class BaseClass {}
    public class SomeClass : BaseClass {}
}