namespace ReAnalyze
{
    public interface ISomeInterface
    {
    }
}