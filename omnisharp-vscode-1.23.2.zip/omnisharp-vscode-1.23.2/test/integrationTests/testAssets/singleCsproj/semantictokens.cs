namespace Test
{
    public class TestProgram
    {
        public static int TestMain(string[] args)
        {
            System.Console.WriteLine(string.Join(',', args));
            return 0;
        }
    }
}
