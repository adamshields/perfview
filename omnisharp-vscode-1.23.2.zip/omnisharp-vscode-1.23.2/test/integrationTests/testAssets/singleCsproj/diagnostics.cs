using System.IO;

namespace Foo
{
    public class FooBar
    {
        public void FooBarBar()
        {
            var notUsed = 3;
        }
    }
}